package com.example.meetandfix;

import java.sql.Struct;

public interface ConexionesURL {
    String Login = "http://leonardosantosgrc.com/g1e1/Login.php";
    String Registro = "http://leonardosantosgrc.com/g1e1/RegistroUsuario.php";
    String Chats = "http://leonardosantosgrc.com/g1e1/Nombrearchivo.php";
    String ModificarUsuario = "http://leonardosantosgrc.com/g1e1/ModificarUsuario.php";
    String EliminarUsuario = "http://leonardosantosgrc.com/g1e1/Nombrearchivo.php";
    String AgendarCita = "http://leonardosantosgrc.com/g1e1/Nombrearchivo.php";
    String ModificarCita = "http://leonardosantosgrc.com/g1e1/Nombrearchivo.php";
    String EliminarCita = "http://leonardosantosgrc.com/g1e1/Nombrearchivo.php";
    String NombreUsuario = "";
    String TelefonoUsuario = "";


}
